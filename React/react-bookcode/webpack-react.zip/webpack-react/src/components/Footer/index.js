import React, { Component } from 'react'

import './index.less'
export default class Footer extends Component {
    render() {
        return (
            <div >
                <h1 className="footer"> 我是footer </h1>
            </div>
        )
    }
}
