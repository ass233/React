import React, { Component } from 'react'

import './index.less'
export default class Header extends Component {
    render() {
        return (
            <div>
                <h1 className="header"> 我是header </h1>
            </div>
        )
    }
}
