





-webpack
-babel 语法解析
-es6/7 基本语法
-npm scripts 统一的任务构建
-eslint 语法检查
-react 组件化 基础类库
-mocha
-karma

-babel-loader babel-core babel-preset-es2015  依赖





$ npm install 


$ npm run build